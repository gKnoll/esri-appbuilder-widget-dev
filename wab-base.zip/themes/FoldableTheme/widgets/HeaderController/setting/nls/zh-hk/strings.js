define({
  "group": "名稱",
  "openAll": "在一個面板中全部開啟",
  "dropDown": "在下拉式功能表中顯示",
  "noGroup": "不存在 widget 群組集。",
  "groupSetLabel": "設定 widget 群組屬性"
});