define({
  "group": "Nosaukums",
  "openAll": "Atvērt visu vienā panelī",
  "dropDown": "Rādīt nolaižamajā izvēlnē",
  "noGroup": "Nav iestatīta logrīku grupa.",
  "groupSetLabel": "Iestatīt logrīku grupas rekvizītus"
});