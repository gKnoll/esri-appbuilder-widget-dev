define({
  "group": "Nimi",
  "openAll": "Avaa kaikki yhdessä paneelissa",
  "dropDown": "Näytä avattavassa valikossa",
  "noGroup": "Pienoisohjelmaryhmää ei ole asetettu.",
  "groupSetLabel": "Aseta pienoisohjelmaryhmien ominaisuudet"
});