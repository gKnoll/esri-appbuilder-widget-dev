define({
  "group": "名前",
  "openAll": "すべてを 1 つのパネルで開く",
  "dropDown": "ドロップダウン メニューに表示",
  "noGroup": "ウィジェット グループ セットがありません。",
  "groupSetLabel": "ウィジェット グループ プロパティの設定"
});