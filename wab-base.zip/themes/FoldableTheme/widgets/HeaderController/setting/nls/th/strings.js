define({
  "group": "ชื่อ",
  "openAll": "เปิดทั้งหมดในหน้าเดียว",
  "dropDown": "แสดงในเมนูแบบเลื่อนลง",
  "noGroup": "ไม่มีการตั้งกลุ่ม widget",
  "groupSetLabel": "การตั้งคุณสมบัติกลุ่ม widget"
});