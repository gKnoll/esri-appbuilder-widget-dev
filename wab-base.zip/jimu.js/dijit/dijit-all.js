define([], function(){
  console.warn("This module is used for build only." +
    " Please don't include this module in your code.");
});
